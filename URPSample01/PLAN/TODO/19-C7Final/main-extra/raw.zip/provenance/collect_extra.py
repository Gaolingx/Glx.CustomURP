"""Validate original C7 inputs and collect completed runs; never substitutes old candidate images."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import csv,json,sys,hashlib
root=Path(__file__).resolve().parent
out=Path('E:/GitHub/Glx.CustomURP/URPSample01/PLAN/TODO/19-C7Final/main-extra'); old=out.parent; base=old.parents[1]/'Done/16-CleanupBaseline/validation'; project=root/'URPSample01'
sys.dont_write_bytecode=True;sys.path.insert(0,str(old));from compare import compare,sha

def dump(path,x): path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
codec=lambda b:hashlib.sha256(b).hexdigest()
checks={s.split()[1]:s.split()[0] for s in (old/'SHA256SUMS.txt').read_text().splitlines() if s.strip()}
anchor={f:sha(old/f) for f in ('compare.py','matrix.csv','raw.zip','pixels-a.zip','pixels-b.zip','run.py')};assert all(h==checks[f] for f,h in anchor.items())
with ZipFile(old/'raw.zip') as z:
 manifest=json.loads(z.read('image-manifest.json')); rawT12={a:z.read(f'T12/baseline/{a}/T12Verification.json') for a in (11,12)}
prev={(r['comparison'],r['api'],r['file']):r['refSHA'] for r in csv.DictReader((old/'matrix.csv').open())}
shelf={}; original=set()
for name in ('pixels-a.zip','pixels-b.zip'):
 with ZipFile(old/name) as z:
  for f in z.namelist():
   if f.startswith('png/') and f.endswith('.png'):
    h=Path(f).stem;assert codec(z.read(f))==h;shelf[h]='../'+name+'!'+f;original.add(h)
scenarios=['T4-C0','T4-matched-5ab7626','T12-C0']; refs={}; verified={}
for api in (11,12):
 dirs=[base/f'baseline/t4/player-d3d{api}',base/f'c3/t4-baseline/player-d3d{api}',Path(f'E:/tmp/C7Final/T12-frozen-{api}')]
 for group,d,n in zip(scenarios,dirs,(14,28,85)):
  if group=='T12-C0':assert (d/'T12Verification.json').read_bytes()==rawT12[api]
  images={p.name:p for p in d.glob('*.png') if group!='T4-C0' or '_Clustered' in p.name};assert len(images)==n
  for f,p in images.items():
   h=sha(p);assert h==manifest[f'{group}/reference/{api}//{f}']==prev[group,str(api),f] and h in original,(api,group,f)
  refs[group,api]=images;verified[f'{group}/{api}']={'directory':str(d),'verifiedPNGs':n}
dump(out/'frozen-inputs.json',{'sha256AgainstHistoricalSHA256SUMS':anchor,'verifiedReferenceSets':verified,'T12ReferenceReportsSHA256':{a:codec(b) for a,b in rawT12.items()}})
projectInfo=json.loads((root/'source.json').read_text()); results={'commit':projectInfo['commit'],'archiveFilesCheckedBeforeUnity':len(projectInfo['sourceFileSHA256BeforeUnity']),'scratch':str(root),'imageRule':'Same API, route, case and state; original compare.py, RGB8 mean <= 2 and peak <= 24; pixels with max-channel difference >8 reported separately.','originalT4Coverage':'14 clustered states per API; original Stencil is not a Forward+ reference. Matched 5ab7626 covers all 28 states.','runs':{},'imageGates':{}}; tables=[]; extra={}; seen=set(); files=[]
for api in (11,12):
 for kind in ('T12','T4build','T4'):
  name=f'{kind}-{api}'; d=root/name; evp=d/'run.json'; finished=evp.is_file(); ev=json.loads(evp.read_text()) if finished else None; state={'status':'finished' if finished else ('started, no exit recorded' if d.exists() else 'not started')};results['runs'][name]=state
  if not finished:
   progress=d/'unity.log'
   if progress.is_file():
    import datetime,re
    snapshot=progress.read_bytes();p=root/f'{name}-partial.log';p.write_bytes(snapshot);files.append((p,name+'/unity.partial.log'));state['observedAt']=datetime.datetime.now().astimezone().isoformat();state['partialLogBytes']=len(snapshot);matches=re.findall(rb'\[\s*\d+s\]\s*\d+ / \d+ variants ready',snapshot);state['lastVariantProgress']=matches[-1].decode() if matches else None
   continue
  for p in sorted(d.iterdir()):
   if p.is_file() and p.suffix.lower()!='.png':files.append((p,name+'/'+p.name))
  state.update({'exit':ev['exit'],'start':ev['start'],'end':ev['end']})
  if kind=='T4build':
   summaries=list((project/'PLAN').rglob(f'CdArenaT4BuildSummary-Direct3D{api}.json'))
   if summaries:
    p,=summaries; files.append((p,name+'/'+p.name));j=json.loads(p.read_text());state.update({k:j[k] for k in ('result','totalErrors','graphicsApis')})
    if ev['exit']==0:
     assert j['result']=='Succeeded' and j['graphicsApis']==f'Direct3D{api}';exe=Path(j['executablePath']);state['playerFileSHA256']={str(f.relative_to(exe.parent)):sha(f) for f in (exe,exe.parent/'CdArenaT4_Data/Managed/Assembly-CSharp.dll',exe.parent/'CdArenaT4_Data/resources.assets')}
   continue
  p=d/('T12Verification.json' if kind=='T12' else 'T4FeatureMatrix.json');
  if not p.exists():state['status']='missing native report';continue
  j=json.loads(p.read_text());state.update({k:j[k] for k in ('unityVersion','graphicsDeviceType','graphicsDeviceName','error')});assert j['graphicsDeviceType']==f'Direct3D{api}'
  if kind=='T12':
   state.update({'completed':j['completed'],'internalPassed':j['passed'],'checksByRoute':{m['name']:[sum(c['passed'] for c in m['cases']),len(m['cases'])] for m in j['modes']}});groups=['T12-C0']
  else:
   state['internalFeaturePassCount']=[sum(e['passed'] for e in j['entries']),len(j['entries'])]; groups=scenarios[:2]
   assert len(j['entries'])==7 and {s['file'] for e in j['entries'] for s in e['states']}==set(refs[groups[-1],api])
  expected=refs[groups[-1],api];actual={p.name for p in d.glob('*.png')};assert actual==set(expected),(name,actual^set(expected))
  for group in groups:
   rows=[]
   for f,a in sorted(refs[group,api].items()):
    b=d/f; ah,bh,n,mean,peak,over,frac,ok=compare(a,b); assert ah==prev[group,str(api),f];
    if bh not in original:extra[bh]=b;shelf[bh]='additional-pixels.zip!png/'+bh+'.png'
    seen.update((ah,bh));rows.append(dict(comparison=group,api=api,file=f,refSHA256=ah,candidateSHA256=bh,pixels=n,meanRGB8=mean,peakRGB8=peak,pxGT8=over,fractionGT8=frac,meanPeakPass=ok))
   tables.extend(rows);results['imageGates'][f'{group}/{api}']={'passed':sum(r['meanPeakPass'] for r in rows),'total':len(rows),'maxMeanRGB8':max(r['meanRGB8'] for r in rows),'maxPeakRGB8':max(r['peakRGB8'] for r in rows),'maxPxGT8':max(r['pxGT8'] for r in rows),'sumPxGT8':sum(r['pxGT8'] for r in rows),'failedImages':[r['file'] for r in rows if not r['meanPeakPass']]}
if tables:
 with (out/'images.csv').open('w',newline='',encoding='utf8') as fp:
  w=csv.DictWriter(fp,list(tables[0]));w.writeheader();w.writerows(tables)
if extra:
 with ZipFile(out/'additional-pixels.zip','w',ZIP_DEFLATED) as z:
  for h,p in sorted(extra.items()):z.write(p,'png/'+h+'.png')
dump(out/'pixel-index.json',{h:shelf[h] for h in sorted(seen)});results['uniquePNGHashes']={'fromExistingArchives':len(seen&original),'includedNew':len(extra)}
with ZipFile(out/'raw.zip','w',ZIP_DEFLATED) as z:
 for p,f in files:z.write(p,f)
 for f in ('copy.log','source.json','acquire.py','collect_extra.py'):z.write(root/f,'provenance/'+f)
dump(out/'results.json',results)
(out/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
print(json.dumps(results,indent=1))
