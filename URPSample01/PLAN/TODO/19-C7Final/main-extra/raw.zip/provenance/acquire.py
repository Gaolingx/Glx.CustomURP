from pathlib import Path
from datetime import datetime
import subprocess as sp, json, hashlib, tarfile
root=Path(__file__).resolve().parent
project=root/'URPSample01'; repo=Path('E:/GitHub/Glx.CustomURP'); rev='1bcc7317fe37ab57ceb13c257b7b8ab346ba3811'
unity=Path('D:/Program Files/Unity/Hub/Editor/2022.3.62f1/Editor/Unity.exe')
paths=['URPSample01/'+s for s in ('Assets','Packages','ProjectSettings')]; cmd=['git','archive',rev,*paths]
h=lambda b: hashlib.sha256(b).hexdigest()
sources={}
with sp.Popen(cmd,cwd=repo,stdout=sp.PIPE) as p:
 with tarfile.open(fileobj=p.stdout,mode='r|') as tar:
  for f in tar:
   if f.isfile():
    digest=h(tar.extractfile(f).read()); assert digest==h((root/f.name).read_bytes()), f.name
    sources[f.name]=digest
 assert p.wait()==0
assert not (project/'Builds').exists()
(root/'source.json').write_text(json.dumps({'commit':rev,'archive':cmd,'project':str(project),'cacheSource':'D:/C7candidate-D4wJLU/URPSample01/Library','copyLog':'copy.log','sourceFileSHA256BeforeUnity':sources},indent=1))
def now(): return datetime.now().astimezone().isoformat()
def run(name,args):
 d=root/name; d.mkdir(); args=[str(x) for x in args]+['-logFile',str(d/'unity.log')]; ev={'name':name,'cwd':str(d),'args':args,'start':now()}; print(name,ev['start'],flush=True)
 try: ev['exit']=sp.run(args,cwd=d).returncode
 finally:
  ev['end']=now(); (d/'run.json').write_text(json.dumps(ev,indent=2));print(name,ev.get('exit'),ev['end'],flush=True)
 return ev['exit']
for api in (11,12):
 name=f'T12-{api}'; run(name,[unity,'-batchmode',f'-force-d3d{api}','-projectPath',project,'-executeMethod','ScreenSpaceLightingT12Verification.RunT12Verification','-ssl-t12-output',root/name])
for api in (11,12):
 name=f'T4build-{api}'; code=run(name,[unity,'-batchmode',f'-force-d3d{api}','-projectPath',project,'-executeMethod',f'ClusteredDeferredArenaBuild.BuildT4D3D{api}AndExit']); player=project/f'Builds/ClusteredDeferredArenaC4T4/Direct3D{api}/CdArenaT4.exe'
 if code==0 and player.exists():
  name=f'T4-{api}';run(name,[player,f'-force-d3d{api}','--cd-output',root/name,'--cd-t4'])
