from pathlib import Path
import datetime, json, os, subprocess, xml.etree.ElementTree as ET, zipfile, hashlib, struct
r = Path(__file__).resolve().parent
u = Path('D:/Program Files/Unity/Hub/Editor/2022.3.62f1/Editor/Unity.exe')
o = r/'tests'
o.mkdir()
logs=[]
for api in (11,12):
 for mode in ('EditMode','PlayMode'):
  stem=f'{mode}-{api}'; xml=o/(stem+'.xml'); log=o/(stem+'.log'); cmd=[u,'-batchmode',f'-force-d3d{api}','-projectPath',r/'URPSample01','-runTests','-testPlatform',mode,'-testResults',xml,'-logFile',log];env=dict(os.environ,C3_MATERIAL_OUTPUT=str(o/'material'));start=datetime.datetime.now().astimezone().isoformat();rc=subprocess.run(cmd,env=env,timeout=1200).returncode
  item=dict(api=api,mode=mode,command=list(map(str,cmd)),exit=rc,start=start,end=datetime.datetime.now().astimezone().isoformat(),C3_MATERIAL_OUTPUT=env['C3_MATERIAL_OUTPUT']);logs.append(item)
  if xml.exists():
   root=ET.parse(xml).getroot();item['result']=root.attrib; item['failures']=[(x.get('fullname'),x.findtext('failure/message')) for x in root.findall('.//test-case') if x.get('result')=='Failed']; print(stem,rc,root.get('passed'),root.get('failed'),item['failures'],flush=True)
  (o/'launches.json').write_text(json.dumps(logs,indent=1))
for d in sorted((o/'material').glob('Direct*')):
 bs=[(d/(s+'.rgba32f')).read_bytes() for s in ('clustered','forwardPlus')];assert all(len(b)==640*360*16 for b in bs); mask=bytes(max(abs(x[i]-y[i])*255 for i in range(3))>8 for x,y in zip(*(struct.iter_unpack('<4f',b) for b in bs)));(d/'mask.json').write_text(json.dumps(dict(over8=sum(mask),maskSha256=hashlib.sha256(mask).hexdigest(),inputSHA256=[hashlib.sha256(b).hexdigest() for b in bs]),indent=1))
with zipfile.ZipFile(r/'main-tests.zip','x',zipfile.ZIP_DEFLATED) as z:
 z.write(__file__,'suite.py');
 for f in o.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(o))
