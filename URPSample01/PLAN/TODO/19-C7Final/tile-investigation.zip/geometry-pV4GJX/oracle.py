"""Run: python oracle.py (stdlib only). Shader arithmetic rounded to binary32, no FMA.
Camera at origin looking down world -Z. Helpers use forward-positive depth after view transform.
Visibility/sector oracle uses binary64 on the actual binary32 light and camera parameters.
"""
import math as m, random, json, hashlib, itertools
from pathlib import Path
from ctypes import c_float
from collections import Counter

src=Path('D:/C7perf-c4a-XL3kqe/URPSample01/Packages/com.unity.render-pipelines.universal@14.0.12/Shaders/Utils/ClusterBuilder.compute')
sha=hashlib.sha256(src.read_bytes()).hexdigest()
assert sha=='eda1c6c615dbdb66f35c55fa849ac2f383824c3b4a6950d96dd493ec828ede27', 'Shader changed; review CPU port before rerunning'
seed=0xC7C0; rng=random.Random(seed)
def f(x): return c_float(x).value
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def unit(a): return tuple(x/m.sqrt(dot(a,a)) for x in a)
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def direction():
    z=rng.uniform(-1,1); t=rng.random()*m.tau; s=m.sqrt(1-z*z)
    return (s*m.cos(t),s*m.sin(t),z)

def coarse(c,r):
    pts=[]
    for sign in itertools.product((-1,1),repeat=3):
        p=[f(x+r*i) for x,i in zip(c,sign)]
        if p[2]<near: return (0,N[1]-1,0,N[0]-1),'near',None
        pts.append([f(f(f((p[j] if ortho else f(p[j]/max(p[2],1e-6)))*s[j])+b[j])*ts[j]) for j in axes])
    lo=list(map(min,zip(*pts))); hi=list(map(max,zip(*pts)))
    if any(hi[j]<0 or lo[j]>N[j]-1 for j in axes): return (1,0,0,0),'empty',(lo,hi)
    def idx(v,j): return min(N[j]-1,max(0,m.floor(v[j])))
    return (idx(lo,1),idx(hi,1),idx(lo,0),idx(hi,0)),'bounds',(lo,hi)

def fine(c,r,axis,angle,tile):
    if angle:
        h=f(m.cos(f(f(angle*f(m.pi/180))*0.5)))
        if h>0.5:
            r=f(r*f(.5/h)); n=f(m.sqrt(f(sum(f(a*a) for a in axis))))
            c=[f(x+f(f(a/n)*r)) for x,a in zip(c,axis)]
    z=1 if ortho else c[2]; r=f(f(r*f(1.0001))+f(.0001))
    for j in axes:
        lo,hi=sorted(f(f(f((tile[j]+k)/ts[j])-b[j])/s[j]) for k in (0,1))
        def pad(a): return r if ortho else f(r*f(m.sqrt(f(1+f(a*a)))))
        if f(c[j]-f(lo*z)) < -pad(lo) or f(f(hi*z)-c[j]) < -pad(hi): return False
    return True

axes=range(2); groups={}; repro={}; near=f(.1); totals=Counter(); cover=Counter()
for ortho,size,angle in itertools.product((True,False),((257,129),(319,183),(320,192)),(0,8,65,119.9,120,120.1,155,178)):
    ts=[v/16 for v in size]; N=list(map(m.ceil,ts)); label=('ortho' if ortho else 'perspective')+('/spot' if angle else '/point'); g=groups.setdefault(label,Counter())
    for i in range(512):
        # Start at a visible pixel center, then place a light around it. No rejection by candidate tests.
        px=[rng.randrange(v) for v in size]; mode=i%8
        if mode in (0,2): px[0]=size[0]-1
        if mode in (1,2): px[1]=size[1]-1
        if mode==3: px[rng.randrange(2)]=0
        if mode==4: px[0]=16*rng.randrange(size[0]//16)
        z=near*1.0005 if mode==5 else 10**rng.uniform(-.95,1.8)
        sy=.1 if ortho else .5/m.tan(m.radians((45,90,135)[i%3])/2)
        s=(f(sy*size[1]/size[0]),f(sy*(-1 if i%2 else 1))); b=(f(.5),f(.5))
        p=[((px[j]+.5)/size[j]-b[j])/s[j]*(1 if ortho else z) for j in axes]+[z]
        footprint=(1 if ortho else z)/(abs(s[1])*size[1]); r=f(footprint*(rng.uniform(.03,.2) if mode<3 else 10**rng.uniform(-1,2.5)))
        axis=tuple(map(f,direction())); n=unit(axis); u=unit(cross(n,(1,0,0))); v=cross(n,u)
        t=m.radians(angle/2)*(.999 if i%3==0 else rng.random()); az=rng.random()*m.tau
        d=[n[j]*m.cos(t)+(u[j]*m.cos(az)+v[j]*m.sin(az))*m.sin(t) for j in range(3)] if angle else direction()
        c=[f(x-y*r*(.995 if i%2 else .45)) for x,y in zip(p,d)]
        delta=[x-y for x,y in zip(p,c)]; dist=m.sqrt(dot(delta,delta)); coshit=dot(n,delta)/dist
        if not (0<dist<r and (not angle or coshit>m.cos(m.radians(angle/2))) and near<p[2]<100):
            cover['discarded_before_tests_after_float_rounding']+=1
            continue
        uv=[p[j]/(1 if ortho else p[2])*s[j]+b[j] for j in axes]; assert all(0<x<1 for x in uv)
        tile=[m.floor(x*k) for x,k in zip(uv,ts)]; assert tile==[x//16 for x in px]
        bounds,branch,mm=coarse(c,r); cy,Cy,cx,Cx=bounds
        ok=cx<=tile[0]<=Cx and cy<=tile[1]<=Cy; hit=fine(c,r,axis,angle,tile)
        counts=dict(witnesses=1,fine_fn=int(not hit),coarse_fn=int(not ok),complete_fn=int(not(ok and hit)))
        g.update(counts); totals.update(counts); cover['near_fallback']+=branch=='near'; cover['partial_tile']+=any(k==nn-1 and sz%16!=0 for k,nn,sz in zip(tile,N,size))
        key=label+('/fine' if not hit else '/coarse');
        if not(ok and hit) and key not in repro:
            repro[key]=dict(size=size,tileWidth=16,scale=s,bias=b,near=near,point_forward_positive=p,center_forward_positive=c,axis_forward_positive=axis,range=r,full_angle=angle,distance=dist,axis_cosine=coshit,pixel=px,tile=tile,count=N,corner_tile_min_max=mm,coarse_bounds=bounds,fine_pass=hit)
result=dict(shader=str(src),sha256=sha,seed=seed,totals=totals,by_projection_and_light=groups,coverage=cover,repros=repro)
Path(__file__).resolve().with_name('results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8'); print(dict(totals),dict(cover)); print(json.dumps(groups)); print(next(iter(repro.values()),None))
