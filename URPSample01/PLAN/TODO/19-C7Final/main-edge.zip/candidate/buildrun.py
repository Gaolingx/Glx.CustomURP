from pathlib import Path
import subprocess as sp,sys,json,shutil,csv
r=Path(__file__).resolve().parent;p=r/'URPSample01';v=sys.argv[1];d=r/v;d.mkdir();unity='D:/Program Files/Unity/Hub/Editor/2022.3.62f1/Editor/Unity.exe'
for api in (11,12):
 sp.run([unity,'-batchmode',f'-force-d3d{api}','-projectPath',str(p),'-executeMethod',f'ClusteredDeferredArenaBuild.BuildD3D{api}AndExit','-logFile',str(d/f'build{api}.log')],check=True,timeout=1500);src=p/f'Builds/ClusteredDeferredArenaC4/Direct3D{api}';dst=d/f'Direct3D{api}';shutil.copytree(src,dst);out=d/f'edge{api}';out.mkdir();rc=sp.run([dst/'CdArena.exe',f'-force-d3d{api}','--cd-edge-tiles','--cd-output',str(out),'-logFile',str(out/'player.log')],timeout=90).returncode;j=json.loads((out/'CdEdgeTiles.json').read_text());print(api,rc,j,flush=True);assert j['graphicsDeviceType']==f'Direct3D{api}' and not j.get('error');assert rc==(2 if v=='base' else 0);assert [c['passed'] for c in j['cases']]==([False]*3+[True]*2 if v=='base' else [True]*5)
