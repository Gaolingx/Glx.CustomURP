using UnityEditor;
using UnityEngine;
public static class C7ReadOnlyProbe {
 public static void Run() {
  var removed = Shader.Find("Hidden/Universal Render Pipeline/StencilDeferred");
  var control = Shader.Find("Universal Render Pipeline/Lit");
  Debug.Log("C7 Shader.Find removed="+(removed == null ? "null" : removed.name)+" positive="+(control == null ? "null" : control.name)+" api="+SystemInfo.graphicsDeviceType);
  EditorApplication.Exit(removed == null && control != null ? 0 : 1);
 }
}
