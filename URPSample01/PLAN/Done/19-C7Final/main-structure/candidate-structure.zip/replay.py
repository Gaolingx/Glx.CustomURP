import os,json,traceback,hashlib,struct
from pathlib import Path
import renderdoc as rd
root=Path('D:/C7-structure-replay'); log=(root/'replay.log').open('w'); stage=rd.ShaderStage.Compute
try:
 for p in sorted(root.glob('D3D*/*.rdc')):
  d=p.parent;cap=rd.OpenCaptureFile();assert cap.OpenFile(str(p),'',None)==rd.ResultCode.Succeeded;result,c=cap.OpenCapture(rd.ReplayOptions(),None);assert result==rd.ResultCode.Succeeded
  sf=c.GetStructuredFile();events=[];api_events=[];summary={'capture':p.name,'driver':cap.DriverName(),'frameNumber':c.GetFrameInfo().frameNumber,'dispatches':[]};print(d,summary,file=log,flush=True)
  def visit(a,parents):
   name=a.GetName(sf);events.append(dict(eid=a.eventId,name=name,parents=parents,flags=int(a.flags),indices=a.numIndices,instances=a.numInstances,dispatch=list(a.dispatchDimension)))
   for e in a.events:
    if e.chunkIndex<len(sf.chunks): api_events.append((e.eventId,sf.chunks[e.chunkIndex].name,a.eventId))
   for child in a.children:visit(child,parents+[name])
  for a in c.GetRootActions():visit(a,[])
  (d/'events.json').write_text(json.dumps(events,indent=1));(d/'api-events.tsv').write_text('EID\tAPI chunk\tAction EID\n'+''.join('%s\t%s\t%s\n'%row for row in sorted(set(api_events))))
  for ev in events:
   flags=ev['flags'];eid=ev['eid']
   if flags & int(rd.ActionFlags.Dispatch):
    c.SetFrameEvent(eid,True);s=c.GetPipelineState();ref=s.GetShaderReflection(stage);assert ref
    info=dict(eid=eid,name=ev['name'],groups=ev['dispatch'],threads=list(ref.dispatchThreadsDimension),shader=str(ref.resourceId),entryPoint=ref.entryPoint,cbuffers=[],srvs=[],uavs=[]);summary['dispatches'].append(info)
    for i,b in enumerate(ref.constantBlocks):
     desc=s.GetConstantBlock(stage,i,0).descriptor
     if not desc.resource:continue
     buf=bytes(c.GetBufferData(desc.resource,desc.byteOffset,b.byteSize));bb=dict(name=b.name,buffer=str(desc.resource),offset=desc.byteOffset,bytes=len(buf),variables=[]);info['cbuffers'].append(bb)
     if 'Clustered Deferred' in ev['parents']:
      (d/('lighting-cb%d.bin'%i)).write_bytes(buf);bb['dump']='lighting-cb%d.bin'%i;bb['slot']=b.fixedBindNumber
      (d/'lighting-shader.txt').write_text(c.DisassembleShader(s.GetComputePipelineObject(),ref,''))
     for v in b.variables:
      if v.type.elements>1 or 'Count' in v.name:
       bb['variables'].append([v.name,v.byteOffset,v.type.elements,v.type.arrayByteStride]);
       if v.name in ('_AdditionalLightsPosition','_AdditionalLightsColor'):
        n=v.type.elements*v.type.arrayByteStride;(d/('%d-%s.bin'%(eid,v.name))).write_bytes(buf[v.byteOffset:v.byteOffset+n]);assert len(buf[v.byteOffset:v.byteOffset+n])==n
    for key,bindings,refs in [('srvs',s.GetReadOnlyResources(stage),ref.readOnlyResources),('uavs',s.GetReadWriteResources(stage),ref.readWriteResources)]:
     for binding in bindings:
      if binding.access.index>=len(refs):continue
      desc=binding.descriptor;r=refs[binding.access.index];info[key].append(dict(name=r.name,resource=str(desc.resource),offset=desc.byteOffset,bytes=desc.byteSize))
    print(info,file=log,flush=True)
   if flags & int(rd.ActionFlags.Drawcall):
    passname=next((v for v in reversed(ev['parents']) if v in ('Render GBuffer','CopyDepth','Clustered Deferred','DrawTransparentObjects','FinalBlit')),None)
    draws=summary.setdefault('drawBindings',{})
    if passname and (passname not in draws or passname=='Clustered Deferred'):
     c.SetFrameEvent(eid,True);s=c.GetPipelineState();ps=rd.ShaderStage.Pixel;rr=s.GetShaderReflection(ps)
     draws.setdefault(passname,[]).append(dict(eid=eid,indices=ev['indices'],PS=str(rr.resourceId),targets=[str(v.resource) for v in s.GetOutputTargets() if v.resource!=rd.ResourceId.Null()],depth=str(s.GetDepthTarget().resource),srvs=[str(v.descriptor.resource) for v in s.GetReadOnlyResources(ps)]))
   if 'FinalBlit' in ev['parents'] and flags & int(rd.ActionFlags.Drawcall):
    c.SetFrameEvent(eid,True);s=c.GetPipelineState();rt=s.GetOutputTargets()[0].resource;tex=next(x for x in c.GetTextures() if x.resourceId==rt);save=rd.TextureSave();save.resourceId=rt;save.destType=rd.FileType.PNG;result=c.SaveTexture(save,str(d/'FinalBlit.png'));assert result==rd.ResultCode.Succeeded,str(result);summary['finalBlit']=dict(eid=eid,target=str(rt),width=tex.width,height=tex.height,format=tex.format.Name())
  (d/'replay.json').write_text(json.dumps(summary,indent=1));c.Shutdown();cap.Shutdown()
except BaseException:
 traceback.print_exc(file=log);log.close();os._exit(1)
log.close();os._exit(0)
