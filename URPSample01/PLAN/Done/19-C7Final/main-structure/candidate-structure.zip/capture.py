import os, time, json, traceback, hashlib, datetime
from pathlib import Path
import renderdoc as rd
root=Path('D:/C7-structure-replay')
log=(root/'capture.log').open('w')
def note(*args):print(datetime.datetime.now().isoformat(),*args,file=log,flush=True)
try:
 for api in (11,12):
  d=root/('D3D%d'%api);d.mkdir();exe=Path('D:/C7candidate-D4wJLU/candidate/Direct3D%d/CdArena.exe'%api)
  args='-force-d3d%d -screen-fullscreen 0 -screen-width 1280 -screen-height 720 --cd-capture --cd-transparent --cd-total-lights 256 --cd-light-counts 256 --cd-screenshot-lights 256 --cd-warmup 480 --cd-output %s -logFile %s'%(api,d,d/'player.log')
  note('ExecuteAndInject',exe,'sha256',hashlib.sha256(exe.read_bytes()).hexdigest(),'cwd',d,'args',args,'template',d/'arena')
  res=rd.ExecuteAndInject(str(exe),str(d),args,[],str(d/'arena'),rd.CaptureOptions(),False);assert res.result,str(res.result);note('ident',res.ident)
  tc=rd.CreateTargetControl('',res.ident,'C7 structure',False);assert tc
  tc.QueueCapture(200,1);note('QueueCapture(200,1)');start=time.monotonic()
  while tc.Connected() and time.monotonic()-start<120:
   msg=tc.ReceiveMessage(None)
   if msg.type!=rd.TargetControlMessageType.Noop:note('message',msg.type)
   if msg.type==rd.TargetControlMessageType.Disconnected:break
  assert time.monotonic()-start<120;tc.Shutdown();note('disconnected; files',list(d.glob('*.rdc')))
  report=json.loads((d/'CdPerf.json').read_text());assert report['completed'] and report['captureOnly'] and report['graphicsDeviceType']=='Direct3D%d'%api and report['transparentFixture'];assert len(list(d.glob('*.rdc')))==1
except BaseException:
 traceback.print_exc(file=log);log.close();os._exit(1)
log.close();os._exit(0)
